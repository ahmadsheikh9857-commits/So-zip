# SO Analyzer - Native Android App

A professional native Android application for analyzing .so (shared object) files with efficient ELF parsing, disassembly, and string extraction.

## Features

✅ **Efficient File Handling** - Streams large .so files without memory issues
✅ **Complete ELF Parser** - Supports 32-bit and 64-bit binaries
✅ **ARM/ARM64 Disassembler** - Decodes native instructions
✅ **String Extraction** - Finds all embedded strings
✅ **Symbol Analysis** - Lists functions and symbols
✅ **Section Viewer** - Displays ELF sections and headers
✅ **Dark Theme UI** - Optimized for code viewing
✅ **File Picker** - Easy file selection from device storage

## Building the APK

### Option 1: Using GitHub Actions (Recommended - Automatic)

1. **Fork or clone this repository to GitHub**
2. **GitHub Actions will automatically build the APK** when you push
3. **Download the APK** from the Actions artifacts

### Option 2: Using Android Studio (Local Build)

1. **Install Android Studio** (https://developer.android.com/studio)
2. **Open this project** in Android Studio
3. **Click Build → Build Bundle(s) / APK(s) → Build APK(s)**
4. **APK will be generated** at `app/build/outputs/apk/release/app-release.apk`

### Option 3: Using Gradle Command Line

```bash
# Make gradlew executable
chmod +x gradlew

# Build release APK
./gradlew assembleRelease

# APK will be at: app/build/outputs/apk/release/app-release.apk
```

## Installation

1. **Enable Unknown Sources** on your Android device (Settings → Security)
2. **Transfer the APK** to your device
3. **Tap the APK file** to install
4. **Grant permissions** when prompted

## Usage

1. **Launch SO Analyzer** from your app drawer
2. **Enter file path** or tap the folder icon to pick a file
3. **Tap ANALYZE** button
4. **Switch tabs** to view:
   - **Code**: Disassembled ARM/ARM64 instructions
   - **Strings**: Extracted strings from binary
   - **Symbols**: Functions and exported symbols
   - **Sections**: ELF sections and headers

## Supported Formats

- **.so files** (shared objects/libraries)
- **32-bit and 64-bit** ELF binaries
- **ARM, ARM64, x86, x86-64** architectures

## Project Structure

```
SOAnalyzer/
├── app/
│   ├── src/main/
│   │   ├── java/com/soanalyzer/
│   │   │   ├── ui/MainActivity.kt
│   │   │   └── utils/ELFParser.kt
│   │   ├── res/
│   │   │   ├── layout/activity_main.xml
│   │   │   ├── values/colors.xml, strings.xml, styles.xml
│   │   │   └── drawable/icons
│   │   └── AndroidManifest.xml
│   ├── build.gradle.kts
│   └── proguard-rules.pro
├── build.gradle.kts
├── settings.gradle.kts
└── gradle/wrapper/
```

## Technical Details

### ELF Parser
- Streams file reading (no memory limits)
- Supports both little-endian and big-endian
- Extracts header, sections, symbols, strings
- Handles 32-bit and 64-bit binaries

### Disassembler
- Decodes common ARM64 instructions
- Generates readable assembly format
- Identifies function boundaries
- Handles branch instructions

### UI
- Material Design 3
- Dark theme optimized for code
- Responsive layout for all screen sizes
- Smooth scrolling for large outputs

## Permissions

- `READ_EXTERNAL_STORAGE` - Read .so files
- `MANAGE_EXTERNAL_STORAGE` - Full file access (Android 11+)

## Minimum Requirements

- **Android 8.0** (API 26) or higher
- **~10 MB** storage space
- **2GB+ RAM** recommended

## License

MIT License - Feel free to use and modify

## Support

For issues or suggestions, please create an issue in the repository.

---

**Built with Kotlin | Material Design | Android SDK 34**
