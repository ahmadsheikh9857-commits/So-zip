package com.soanalyzer.utils

import java.io.File
import java.io.RandomAccessFile
import kotlin.math.min

data class ELFHeader(
    val magic: String,
    val elfClass: String,
    val endianness: String,
    val machine: String,
    val type: String,
    val entry: Long,
    val sectionCount: Int,
    val sectionHeaderOffset: Long,
    val sectionHeaderSize: Int,
    val stringTableIndex: Int
)

data class Section(
    val name: String,
    val type: String,
    val addr: Long,
    val offset: Long,
    val size: Long,
    val flags: List<String>
)

data class Symbol(
    val name: String,
    val value: Long,
    val size: Long,
    val type: String,
    val binding: String
)

data class ExtractedString(
    val offset: Long,
    val value: String,
    val section: String
)

data class Instruction(
    val address: Long,
    val bytes: String,
    val mnemonic: String,
    val operands: String
)

class ELFParser(private val file: File) {
    private var littleEndian = true
    private val buffer = ByteArray(4096)

    fun parse(): ELFAnalysis {
        return RandomAccessFile(file, "r").use { raf ->
            val header = parseHeader(raf)
            val sections = parseSections(raf, header)
            val symbols = parseSymbols(raf, header, sections)
            val strings = extractStrings(raf, sections)
            val code = disassembleCode(raf, sections)

            ELFAnalysis(
                header = header,
                sections = sections,
                symbols = symbols,
                strings = strings,
                code = code,
                fileSize = file.length(),
                fileName = file.name
            )
        }
    }

    private fun parseHeader(raf: RandomAccessFile): ELFHeader {
        raf.seek(0)
        val magic = ByteArray(4)
        raf.readFully(magic)

        if (magic[0] != 0x7F.toByte() || magic[1] != 'E'.code.toByte() || 
            magic[2] != 'L'.code.toByte() || magic[3] != 'F'.code.toByte()) {
            throw IllegalArgumentException("Not a valid ELF file")
        }

        val elfClass = raf.readByte().toInt()
        val endian = raf.readByte().toInt()
        littleEndian = endian == 1

        raf.seek(16)
        val type = readU16(raf)
        val machine = readU16(raf)
        val version = readU32(raf)

        val entry = if (elfClass == 2) readU64(raf) else readU32(raf).toLong()
        val phoff = if (elfClass == 2) readU64(raf) else readU32(raf).toLong()
        val shoff = if (elfClass == 2) readU64(raf) else readU32(raf).toLong()
        val flags = readU32(raf)
        val ehsize = readU16(raf)
        val phentsize = readU16(raf)
        val phnum = readU16(raf)
        val shentsize = readU16(raf)
        val shnum = readU16(raf)
        val shstrndx = readU16(raf)

        val machineNames = mapOf(
            0x28 to "ARM",
            0xB7 to "ARM64",
            0x3E to "x86-64",
            0x03 to "x86"
        )

        return ELFHeader(
            magic = "ELF",
            elfClass = if (elfClass == 2) "64-bit" else "32-bit",
            endianness = if (littleEndian) "little" else "big",
            machine = machineNames[machine] ?: "Unknown (0x${machine.toString(16)})",
            type = if (type == 3) "Shared Object" else "Type $type",
            entry = entry,
            sectionCount = shnum,
            sectionHeaderOffset = shoff,
            sectionHeaderSize = shentsize,
            stringTableIndex = shstrndx
        )
    }

    private fun parseSections(raf: RandomAccessFile, header: ELFHeader): List<Section> {
        val sections = mutableListOf<Section>()
        val is64Bit = header.elfClass == "64-bit"

        // Read section header string table
        raf.seek(header.sectionHeaderOffset + header.stringTableIndex * header.sectionHeaderSize)
        val shstrtabOffset = if (is64Bit) {
            raf.seek(raf.filePointer + 32)
            readU64(raf)
        } else {
            raf.seek(raf.filePointer + 16)
            readU32(raf).toLong()
        }

        for (i in 0 until header.sectionCount) {
            raf.seek(header.sectionHeaderOffset + i * header.sectionHeaderSize)

            val nameOffset = readU32(raf)
            val type = readU32(raf)
            val flags = if (is64Bit) readU64(raf) else readU32(raf).toLong()
            val addr = if (is64Bit) readU64(raf) else readU32(raf).toLong()
            val offset = if (is64Bit) readU64(raf) else readU32(raf).toLong()
            val size = if (is64Bit) readU64(raf) else readU32(raf).toLong()

            val name = readStringAt(raf, shstrtabOffset + nameOffset)

            val flagList = mutableListOf<String>()
            if (flags and 0x1L != 0L) flagList.add("WRITE")
            if (flags and 0x2L != 0L) flagList.add("ALLOC")
            if (flags and 0x4L != 0L) flagList.add("EXEC")

            val typeNames = mapOf(
                0 to "NULL", 1 to "PROGBITS", 2 to "SYMTAB", 3 to "STRTAB",
                6 to "DYNAMIC", 8 to "NOBITS", 9 to "REL"
            )

            sections.add(
                Section(
                    name = name.ifEmpty { "<section $i>" },
                    type = typeNames[type] ?: "Unknown",
                    addr = addr,
                    offset = offset,
                    size = size,
                    flags = flagList
                )
            )
        }

        return sections
    }

    private fun parseSymbols(raf: RandomAccessFile, header: ELFHeader, sections: List<Section>): List<Symbol> {
        val symbols = mutableListOf<Symbol>()
        val symtabSection = sections.find { it.type == "SYMTAB" } ?: return symbols
        val strtabSection = sections.find { it.name == ".strtab" } ?: return symbols

        val is64Bit = header.elfClass == "64-bit"
        val entrySize = if (is64Bit) 24 else 16
        val numSymbols = (symtabSection.size / entrySize).toInt()

        for (i in 0 until numSymbols) {
            raf.seek(symtabSection.offset + i * entrySize)

            val nameOffset = readU32(raf)
            val (value, size, info, shndx) = if (is64Bit) {
                val info = raf.readByte().toInt()
                val other = raf.readByte()
                val shndx = readU16(raf)
                val value = readU64(raf)
                val size = readU64(raf)
                Triple(value, size, info) to shndx
            } else {
                val value = readU32(raf).toLong()
                val size = readU32(raf).toLong()
                val info = raf.readByte().toInt()
                val other = raf.readByte()
                val shndx = readU16(raf)
                Triple(value, size, info) to shndx
            }

            val name = readStringAt(raf, strtabSection.offset + nameOffset)
            val type = info and 0xF
            val binding = info shr 4

            val typeNames = listOf("NOTYPE", "OBJECT", "FUNC", "SECTION", "FILE")
            val bindingNames = listOf("LOCAL", "GLOBAL", "WEAK")

            if (name.isNotEmpty() && type == 2) { // Only functions
                symbols.add(
                    Symbol(
                        name = name,
                        value = value.first,
                        size = value.second,
                        type = typeNames.getOrElse(type) { "UNKNOWN" },
                        binding = bindingNames.getOrElse(binding) { "UNKNOWN" }
                    )
                )
            }
        }

        return symbols
    }

    private fun extractStrings(raf: RandomAccessFile, sections: List<Section>): List<ExtractedString> {
        val strings = mutableListOf<ExtractedString>()
        val targetSections = sections.filter { it.name in listOf(".rodata", ".data") }

        for (section in targetSections) {
            if (section.size == 0L) continue

            raf.seek(section.offset)
            var currentString = ""
            var startOffset = 0L

            val bytesToRead = min(section.size, 1024 * 1024).toInt() // Limit to 1MB per section
            val data = ByteArray(bytesToRead)
            raf.readFully(data)

            for (i in data.indices) {
                val byte = data[i].toInt() and 0xFF

                when {
                    byte in 32..126 -> {
                        if (currentString.isEmpty()) startOffset = i.toLong()
                        currentString += byte.toChar()
                    }
                    byte == 0 && currentString.length >= 4 -> {
                        strings.add(
                            ExtractedString(
                                offset = section.offset + startOffset,
                                value = currentString,
                                section = section.name
                            )
                        )
                        currentString = ""
                    }
                    else -> currentString = ""
                }
            }
        }

        return strings
    }

    private fun disassembleCode(raf: RandomAccessFile, sections: List<Section>): List<Instruction> {
        val code = mutableListOf<Instruction>()
        val textSection = sections.find { it.name == ".text" } ?: return code

        if (textSection.size == 0L) return code

        raf.seek(textSection.offset)
        val bytesToRead = min(textSection.size, 65536).toInt() // Limit to 64KB
        val data = ByteArray(bytesToRead)
        raf.readFully(data)

        val numInstructions = bytesToRead / 4
        for (i in 0 until numInstructions) {
            val offset = i * 4
            val inst = (data[offset].toInt() and 0xFF) or
                    ((data[offset + 1].toInt() and 0xFF) shl 8) or
                    ((data[offset + 2].toInt() and 0xFF) shl 16) or
                    ((data[offset + 3].toInt() and 0xFF) shl 24)

            val addr = textSection.addr + offset
            val (mnemonic, operands) = decodeARM64Instruction(inst)

            code.add(
                Instruction(
                    address = addr,
                    bytes = "0x${inst.toString(16).padStart(8, '0')}",
                    mnemonic = mnemonic,
                    operands = operands
                )
            )
        }

        return code
    }

    private fun decodeARM64Instruction(inst: Int): Pair<String, String> {
        return when {
            inst == 0xd65f03c0 -> "ret" to ""
            inst == 0xd503201f -> "nop" to ""
            inst and 0xfc000000 == 0x14000000 -> {
                val imm26 = inst and 0x3FFFFFF
                val offset = (imm26 shl 6) shr 4
                "b" to "0x${(offset).toString(16)}"
            }
            inst and 0xfc000000 == 0x94000000 -> {
                val imm26 = inst and 0x3FFFFFF
                val offset = (imm26 shl 6) shr 4
                "bl" to "0x${offset.toString(16)}"
            }
            else -> "unknown" to ""
        }
    }

    private fun readU16(raf: RandomAccessFile): Int {
        val b1 = raf.readByte().toInt() and 0xFF
        val b2 = raf.readByte().toInt() and 0xFF
        return if (littleEndian) b1 or (b2 shl 8) else (b1 shl 8) or b2
    }

    private fun readU32(raf: RandomAccessFile): Long {
        val b1 = raf.readByte().toInt() and 0xFF
        val b2 = raf.readByte().toInt() and 0xFF
        val b3 = raf.readByte().toInt() and 0xFF
        val b4 = raf.readByte().toInt() and 0xFF
        return if (littleEndian) {
            (b1 or (b2 shl 8) or (b3 shl 16) or (b4 shl 24)).toLong() and 0xFFFFFFFFL
        } else {
            ((b1 shl 24) or (b2 shl 16) or (b3 shl 8) or b4).toLong() and 0xFFFFFFFFL
        }
    }

    private fun readU64(raf: RandomAccessFile): Long {
        val low = readU32(raf)
        val high = readU32(raf)
        return if (littleEndian) low or (high shl 32) else (high shl 32) or low
    }

    private fun readStringAt(raf: RandomAccessFile, offset: Long): String {
        val savedPos = raf.filePointer
        raf.seek(offset)
        val sb = StringBuilder()
        while (true) {
            val byte = raf.readByte().toInt() and 0xFF
            if (byte == 0) break
            if (byte in 32..126) sb.append(byte.toChar())
        }
        raf.seek(savedPos)
        return sb.toString()
    }
}

data class ELFAnalysis(
    val header: ELFHeader,
    val sections: List<Section>,
    val symbols: List<Symbol>,
    val strings: List<ExtractedString>,
    val code: List<Instruction>,
    val fileSize: Long,
    val fileName: String
)
