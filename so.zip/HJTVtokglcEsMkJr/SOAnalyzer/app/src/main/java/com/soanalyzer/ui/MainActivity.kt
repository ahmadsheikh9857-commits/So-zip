package com.soanalyzer.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.DocumentsContract
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import com.google.android.material.tabs.TabLayout
import com.soanalyzer.R
import com.soanalyzer.utils.ELFParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : AppCompatActivity() {
    private lateinit var filePathInput: EditText
    private lateinit var analyzeButton: MaterialButton
    private lateinit var pickButton: MaterialButton
    private lateinit var progressBar: ProgressBar
    private lateinit var outputText: TextView
    private lateinit var tabLayout: TabLayout
    private lateinit var scrollView: ScrollView

    private var currentAnalysis: com.soanalyzer.utils.ELFAnalysis? = null
    private var currentTab = "code"

    companion object {
        private const val PICK_FILE_REQUEST = 1
        private const val PERMISSION_REQUEST = 2
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        filePathInput = findViewById(R.id.filePathInput)
        analyzeButton = findViewById(R.id.analyzeButton)
        pickButton = findViewById(R.id.pickButton)
        progressBar = findViewById(R.id.progressBar)
        outputText = findViewById(R.id.outputText)
        tabLayout = findViewById(R.id.tabLayout)
        scrollView = findViewById(R.id.scrollView)

        analyzeButton.setOnClickListener { analyzeFile() }
        pickButton.setOnClickListener { pickFile() }

        tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                currentTab = when (tab.position) {
                    0 -> "code"
                    1 -> "strings"
                    2 -> "symbols"
                    3 -> "sections"
                    else -> "code"
                }
                updateOutput()
            }

            override fun onTabUnselected(tab: TabLayout.Tab) {}
            override fun onTabReselected(tab: TabLayout.Tab) {}
        })

        checkPermissions()
    }

    private fun checkPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.MANAGE_EXTERNAL_STORAGE
                ) == PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.MANAGE_EXTERNAL_STORAGE),
                    PERMISSION_REQUEST
                )
            }
        }
    }

    private fun pickFile() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        startActivityForResult(intent, PICK_FILE_REQUEST)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == PICK_FILE_REQUEST && resultCode == RESULT_OK) {
            data?.data?.let { uri ->
                val path = getRealPathFromURI(uri)
                if (path != null) {
                    filePathInput.setText(path)
                }
            }
        }
    }

    private fun getRealPathFromURI(uri: Uri): String? {
        return try {
            val cursor = contentResolver.query(uri, null, null, null, null)
            cursor?.use {
                val nameIndex = it.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
                it.moveToFirst()
                val fileName = it.getString(nameIndex)
                val cacheFile = File(cacheDir, fileName)
                contentResolver.openInputStream(uri)?.use { input ->
                    cacheFile.outputStream().use { output ->
                        input.copyTo(output)
                    }
                }
                cacheFile.absolutePath
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun analyzeFile() {
        val path = filePathInput.text.toString().trim()
        if (path.isEmpty()) {
            Toast.makeText(this, "Please enter a file path", Toast.LENGTH_SHORT).show()
            return
        }

        val file = File(path)
        if (!file.exists()) {
            Toast.makeText(this, "File not found", Toast.LENGTH_SHORT).show()
            return
        }

        if (!file.name.endsWith(".so")) {
            Toast.makeText(this, "Please select a .so file", Toast.LENGTH_SHORT).show()
            return
        }

        analyzeButton.isEnabled = false
        progressBar.visibility = View.VISIBLE
        outputText.text = "Analyzing..."

        lifecycleScope.launch {
            try {
                val analysis = withContext(Dispatchers.Default) {
                    ELFParser(file).parse()
                }
                currentAnalysis = analysis
                updateOutput()
            } catch (e: Exception) {
                outputText.text = "Error: ${e.message}"
            } finally {
                analyzeButton.isEnabled = true
                progressBar.visibility = View.GONE
            }
        }
    }

    private fun updateOutput() {
        val analysis = currentAnalysis ?: return

        val output = when (currentTab) {
            "code" -> formatCodeOutput(analysis)
            "strings" -> formatStringsOutput(analysis)
            "symbols" -> formatSymbolsOutput(analysis)
            "sections" -> formatSectionsOutput(analysis)
            else -> ""
        }

        outputText.text = output
        scrollView.scrollTo(0, 0)
    }

    private fun formatCodeOutput(analysis: com.soanalyzer.utils.ELFAnalysis): String {
        if (analysis.code.isEmpty()) return "No code found"

        return buildString {
            appendLine("[DISASSEMBLED CODE]")
            appendLine("Address        Bytes              Mnemonic  Operands")
            appendLine("─".repeat(80))
            analysis.code.take(500).forEach { inst ->
                appendLine(
                    "0x${inst.address.toString(16).padStart(8, '0')}  " +
                            "${inst.bytes.padEnd(18)}  " +
                            "${inst.mnemonic.padEnd(10)} ${inst.operands}"
                )
            }
            if (analysis.code.size > 500) {
                appendLine("\n... and ${analysis.code.size - 500} more instructions")
            }
        }
    }

    private fun formatStringsOutput(analysis: com.soanalyzer.utils.ELFAnalysis): String {
        if (analysis.strings.isEmpty()) return "No strings found"

        return buildString {
            appendLine("[EXTRACTED STRINGS]")
            appendLine("Offset          Section    Value")
            appendLine("─".repeat(80))
            analysis.strings.take(500).forEach { str ->
                appendLine(
                    "0x${str.offset.toString(16).padStart(8, '0')}  " +
                            "${str.section.padEnd(10)} \"${str.value.take(60)}\""
                )
            }
            if (analysis.strings.size > 500) {
                appendLine("\n... and ${analysis.strings.size - 500} more strings")
            }
        }
    }

    private fun formatSymbolsOutput(analysis: com.soanalyzer.utils.ELFAnalysis): String {
        if (analysis.symbols.isEmpty()) return "No symbols found"

        return buildString {
            appendLine("[SYMBOLS & FUNCTIONS]")
            appendLine("Name                      Address         Type      Binding  Size")
            appendLine("─".repeat(80))
            analysis.symbols.take(500).forEach { sym ->
                appendLine(
                    "${sym.name.padEnd(25)} " +
                            "0x${sym.value.toString(16).padStart(8, '0')}  " +
                            "${sym.type.padEnd(9)} " +
                            "${sym.binding.padEnd(8)} " +
                            "${sym.size}"
                )
            }
            if (analysis.symbols.size > 500) {
                appendLine("\n... and ${analysis.symbols.size - 500} more symbols")
            }
        }
    }

    private fun formatSectionsOutput(analysis: com.soanalyzer.utils.ELFAnalysis): String {
        return buildString {
            appendLine("[ELF HEADER]")
            appendLine("Class:       ${analysis.header.elfClass}")
            appendLine("Endianness:  ${analysis.header.endianness}")
            appendLine("Machine:     ${analysis.header.machine}")
            appendLine("Type:        ${analysis.header.type}")
            appendLine("Entry Point: 0x${analysis.header.entry.toString(16)}")
            appendLine("File Size:   ${analysis.fileSize} bytes")
            appendLine()
            appendLine("[SECTIONS]")
            appendLine("Name                Type       Address         Offset          Size        Flags")
            appendLine("─".repeat(100))
            analysis.sections.forEach { sec ->
                appendLine(
                    "${sec.name.padEnd(20)} " +
                            "${sec.type.padEnd(10)} " +
                            "0x${sec.addr.toString(16).padStart(8, '0')}  " +
                            "0x${sec.offset.toString(16).padStart(8, '0')}  " +
                            "${sec.size.toString().padEnd(11)} " +
                            sec.flags.joinToString(",")
                )
            }
        }
    }
}
